import asyncio
import copy
import time
import types
from typing import Dict, List, Optional, Sequence, Type, Union

from pymilvus.client import type_info
from pymilvus.client.abstract import AnnSearchRequest, BaseRanker
from pymilvus.client.connection_manager import AsyncConnectionManager, ConnectionConfig
from pymilvus.client.constants import CLUSTER_ID, DEFAULT_CONSISTENCY_LEVEL
from pymilvus.client.search_aggregation import SearchAggregation
from pymilvus.client.types import (
    _DEFAULT_RETAINED_SEGMENT_STATES,
    CompactionPlans,
    ExceptionsMessage,
    FunctionType,
    LoadState,
    OmitZeroDict,
    RefreshExternalCollectionJobInfo,
    ResourceGroupConfig,
    RestoreSnapshotJobInfo,
    RoleInfo,
    SegmentInfo,
    SegmentState,
    SnapshotInfo,
    UserInfo,
)
from pymilvus.client.utils import (
    convert_struct_fields_to_user_format,
)
from pymilvus.decorators import deprecated
from pymilvus.exceptions import (
    DataTypeNotMatchException,
    MilvusException,
    ParamError,
    PrimaryKeyException,
)
from pymilvus.function_chain import FunctionChain
from pymilvus.orm.collection import CollectionSchema, Function, FunctionScore
from pymilvus.orm.schema import FieldSchema, StructFieldSchema
from pymilvus.orm.types import DataType

from .async_optimize_task import AsyncOptimizeTask
from .base import BaseMilvusClient
from .check import validate_param
from .index import IndexParam, IndexParams, extract_bound_index_param
from .optimize_task import OptimizeResult, ProgressStage, parse_target_size


class AsyncMilvusClient(BaseMilvusClient):
    """AsyncMilvusClient is an EXPERIMENTAL class
    which only provides part of MilvusClient's methods"""

    def __init__(
        self,
        uri: str = "http://localhost:19530",
        user: str = "",
        password: str = "",
        db_name: str = "",
        token: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> None:
        # Build token from user/password if not provided
        final_token = token
        if not token and user and password:
            final_token = f"{user}:{password}"

        # Store config for deferred connection
        self._dedicated = kwargs.pop("dedicated", False)
        kwargs.pop("cluster_id", None)
        self._config = ConnectionConfig.from_uri(
            uri,
            token=final_token,
            db_name=db_name,
            **kwargs,
        )
        self._timeout = timeout
        self._manager: Optional[AsyncConnectionManager] = None
        self._handler = None
        self._using = None
        self.is_self_hosted = None
        self._closed = False

    def session(self, cluster_id: str) -> "AsyncMilvusClientSession":
        """Create a lightweight client session pinned to a target cluster."""
        validate_param("cluster_id", cluster_id, str)
        return AsyncMilvusClientSession(self, cluster_id)

    async def __aenter__(self):
        """Async context manager entry: connect and return self."""
        await self._connect()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[types.TracebackType],
    ) -> None:
        """Async context manager exit: close the client."""
        await self.close()

    async def _connect(self) -> None:
        """Establish the async connection. Call this before using the client."""
        if self._handler is not None:
            return  # Already connected

        self._manager = AsyncConnectionManager.get_instance()
        self._handler = await self._manager.get_or_create(
            self._config,
            dedicated=self._dedicated,
            client=self,
            timeout=self._timeout,
        )
        self._using = f"cm-async-{id(self._handler)}"
        self.is_self_hosted = bool(self._handler.get_server_type() == "milvus")

    async def _get_connection(self):
        """Return the handler for this client, auto-connecting if needed."""
        if self._closed:
            raise MilvusException(message="should create connection first")
        if self._handler is None:
            await self._connect()
        return self._handler

    def get_server_type(self) -> str:
        """Get the server type. Requires the client to be connected."""
        if self._handler is None:
            raise MilvusException(
                message="Client not connected. Call await client._connect() first."
            )
        return self._handler.get_server_type()

    async def create_collection(
        self,
        collection_name: str,
        dimension: Optional[int] = None,
        primary_field_name: str = "id",  # default is "id"
        id_type: str = "int",  # or "string",
        vector_field_name: str = "vector",  # default is  "vector"
        metric_type: str = "COSINE",
        auto_id: bool = False,
        timeout: Optional[float] = None,
        schema: Optional[CollectionSchema] = None,
        index_params: Optional[IndexParams] = None,
        **kwargs,
    ):
        if schema is None:
            return await self._fast_create_collection(
                collection_name,
                dimension,
                primary_field_name=primary_field_name,
                id_type=id_type,
                vector_field_name=vector_field_name,
                metric_type=metric_type,
                auto_id=auto_id,
                timeout=timeout,
                **kwargs,
            )

        return await self._create_collection_with_schema(
            collection_name, schema, index_params, timeout=timeout, **kwargs
        )

    async def _fast_create_collection(
        self,
        collection_name: str,
        dimension: int,
        primary_field_name: str = "id",  # default is "id"
        id_type: Union[DataType, str] = DataType.INT64,  # or "string",
        vector_field_name: str = "vector",  # default is  "vector"
        metric_type: str = "COSINE",
        auto_id: bool = False,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        if dimension is None:
            msg = "missing requried argument: 'dimension'"
            raise TypeError(msg)
        if "enable_dynamic_field" not in kwargs:
            kwargs["enable_dynamic_field"] = True

        schema = self.create_schema(auto_id=auto_id, **kwargs)

        if id_type in ("int", DataType.INT64):
            pk_data_type = DataType.INT64
        elif id_type in ("string", "str", DataType.VARCHAR):
            pk_data_type = DataType.VARCHAR
        else:
            raise PrimaryKeyException(message=ExceptionsMessage.PrimaryFieldType)

        pk_args = {}
        if "max_length" in kwargs and pk_data_type == DataType.VARCHAR:
            pk_args["max_length"] = kwargs["max_length"]

        schema.add_field(primary_field_name, pk_data_type, is_primary=True, **pk_args)
        vector_type = DataType.FLOAT_VECTOR
        schema.add_field(vector_field_name, vector_type, dim=dimension)
        schema.verify()

        conn = await self._get_connection()
        if "consistency_level" not in kwargs:
            kwargs["consistency_level"] = DEFAULT_CONSISTENCY_LEVEL
        await conn.create_collection(
            collection_name,
            schema,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

        index_params = IndexParams()
        index_params.add_index(vector_field_name, index_type="AUTOINDEX", metric_type=metric_type)
        await self.create_index(collection_name, index_params, timeout=timeout)
        await self.load_collection(collection_name, timeout=timeout)

    async def _create_collection_with_schema(
        self,
        collection_name: str,
        schema: CollectionSchema,
        index_params: IndexParams,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        schema.verify()

        conn = await self._get_connection()
        if "consistency_level" not in kwargs:
            kwargs["consistency_level"] = DEFAULT_CONSISTENCY_LEVEL
        await conn.create_collection(
            collection_name,
            schema,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

        if index_params:
            await self.create_index(collection_name, index_params, timeout=timeout)
            await self.load_collection(collection_name, timeout=timeout)

    async def drop_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.drop_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def truncate_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.truncate_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def rename_collection(
        self,
        old_name: str,
        new_name: str,
        target_db: Optional[str] = "",
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.rename_collection(
            old_name,
            new_name,
            target_db,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def load_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.load_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def release_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.release_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def create_index(
        self,
        collection_name: str,
        index_params: IndexParams,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        validate_param("collection_name", collection_name, str)
        validate_param("index_params", index_params, IndexParams)
        if len(index_params) == 0:
            raise ParamError(message="IndexParams is empty, no index can be created")

        for index_param in index_params:
            await self._create_index(collection_name, index_param, timeout=timeout, **kwargs)

    async def _create_index(
        self,
        collection_name: str,
        index_param: IndexParam,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.create_index(
            collection_name,
            index_param.field_name,
            index_param.get_index_configs(),
            timeout=timeout,
            index_name=index_param.index_name,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_index(
        self, collection_name: str, index_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.drop_index(
            collection_name,
            "",
            index_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def create_partition(
        self, collection_name: str, partition_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.create_partition(
            collection_name,
            partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_partition(
        self, collection_name: str, partition_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.drop_partition(
            collection_name,
            partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def load_partitions(
        self,
        collection_name: str,
        partition_names: Union[str, List[str]],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        if isinstance(partition_names, str):
            partition_names = [partition_names]

        conn = await self._get_connection()
        await conn.load_partitions(
            collection_name,
            partition_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def release_partitions(
        self,
        collection_name: str,
        partition_names: Union[str, List[str]],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        if isinstance(partition_names, str):
            partition_names = [partition_names]
        conn = await self._get_connection()
        await conn.release_partitions(
            collection_name,
            partition_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def has_partition(
        self, collection_name: str, partition_name: str, timeout: Optional[float] = None, **kwargs
    ) -> bool:
        conn = await self._get_connection()
        return await conn.has_partition(
            collection_name,
            partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_partitions(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_partitions(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def insert(
        self,
        collection_name: str,
        data: Union[Dict, List[Dict]],
        timeout: Optional[float] = None,
        partition_name: Optional[str] = "",
        **kwargs,
    ) -> Dict:
        # If no data provided, we cannot input anything
        if isinstance(data, dict):
            data = [data]

        msg = "wrong type of argument 'data',"
        msg += f"expected 'Dict' or list of 'Dict', got '{type(data).__name__}'"

        if not isinstance(data, list):
            raise TypeError(msg)

        if len(data) == 0:
            return {"insert_count": 0, "ids": []}

        conn = await self._get_connection()
        # Insert into the collection.
        res = await conn.insert_rows(
            collection_name,
            data,
            partition_name=partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        return OmitZeroDict(
            {
                "insert_count": res.insert_count,
                "ids": res.primary_keys,
                "cost": res.cost,
            }
        )

    async def upsert(
        self,
        collection_name: str,
        data: Union[Dict, List[Dict]],
        timeout: Optional[float] = None,
        partition_name: Optional[str] = "",
        **kwargs,
    ) -> Dict:
        """Upsert data into the collection asynchronously.

        Args:
            collection_name (str): Name of the collection to upsert into.
            data (List[Dict[str, any]]): A list of dicts to pass in. If list not provided, will
                cast to list.
            timeout (float, optional): The timeout to use, will override init timeout. Defaults
                to None.
            partition_name (str, optional): Name of the partition to upsert into.
            **kwargs (dict): Extra keyword arguments.

                * *partial_update* (bool, optional): Whether this is a partial update operation.
                    If True, only the specified fields will be updated while others remain unchanged
                    Default is False.
                * *field_ops* (Dict[str, Any], optional): Per-field partial-update operators that
                    describe how to merge the provided values against the existing rows. Each
                    value may be a :class:`~pymilvus.FieldOp` factory result (e.g.
                    ``FieldOp.array_append()``), a string alias (``"array_append"``,
                    ``"array_remove"``, ``"replace"``), or a
                    :class:`schema_pb2.FieldPartialUpdateOp` message. Any non-REPLACE op implies
                    partial_update=True.

        Raises:
            DataNotMatchException: If the data has missing fields an exception will be thrown.
            MilvusException: General Milvus error on upsert.

        Returns:
            Dict: Number of rows that were upserted.
        """
        # If no data provided, we cannot input anything
        if isinstance(data, dict):
            data = [data]

        msg = "wrong type of argument 'data',"
        msg += f"expected 'Dict' or list of 'Dict', got '{type(data).__name__}'"

        if not isinstance(data, list):
            raise TypeError(msg)

        if len(data) == 0:
            return {"upsert_count": 0, "ids": []}

        conn = await self._get_connection()
        # Upsert into the collection.
        res = await conn.upsert_rows(
            collection_name,
            data,
            partition_name=partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

        return OmitZeroDict(
            {
                "upsert_count": res.upsert_count,
                "cost": res.cost,
                "ids": res.primary_keys,
            }
        )

    async def hybrid_search(
        self,
        collection_name: str,
        reqs: List[AnnSearchRequest],
        ranker: Union[BaseRanker, Function],
        limit: int = 10,
        output_fields: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        partition_names: Optional[List[str]] = None,
        **kwargs,
    ) -> List[List[dict]]:
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()
        kwargs = self._with_cluster_id(kwargs)
        return await conn.hybrid_search(
            collection_name,
            reqs,
            ranker,
            limit=limit,
            partition_names=partition_names,
            output_fields=output_fields,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def search(
        self,
        collection_name: str,
        data: Optional[Union[List[list], list]] = None,
        filter: str = "",
        limit: int = 10,
        output_fields: Optional[List[str]] = None,
        search_params: Optional[dict] = None,
        timeout: Optional[float] = None,
        partition_names: Optional[List[str]] = None,
        anns_field: Optional[str] = None,
        ranker: Optional[Union[Function, FunctionScore]] = None,
        function_chains: Optional[Union[FunctionChain, List[FunctionChain]]] = None,
        ids: Optional[Union[List[int], List[str], str, int]] = None,
        search_aggregation: Optional[SearchAggregation] = None,
        **kwargs,
    ) -> List[List[dict]]:
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()
        kwargs = self._with_cluster_id(kwargs)
        return await conn.search(
            collection_name=collection_name,
            anns_field=anns_field or "",
            param=search_params or {},
            expression=filter,
            limit=limit,
            data=data,
            ids=ids,
            output_fields=output_fields,
            partition_names=partition_names,
            expr_params=kwargs.pop("filter_params", {}),
            timeout=timeout,
            ranker=ranker,
            function_chains=function_chains,
            search_aggregation=search_aggregation,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def query(
        self,
        collection_name: str,
        filter: str = "",
        output_fields: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        ids: Optional[Union[List, str, int]] = None,
        partition_names: Optional[List[str]] = None,
        **kwargs,
    ) -> List[dict]:
        if filter and not isinstance(filter, str):
            raise DataTypeNotMatchException(message=ExceptionsMessage.ExprType % type(filter))

        if filter and ids is not None:
            raise ParamError(message=ExceptionsMessage.AmbiguousQueryFilterParam)

        if isinstance(ids, (int, str)):
            ids = [ids]

        conn = await self._get_connection()

        if ids:
            try:
                schema_dict, _ = await conn._get_schema(
                    collection_name,
                    timeout=timeout,
                    context=self._generate_call_context(**kwargs),
                    **kwargs,
                )
            except Exception as ex:
                raise ex from ex
            filter = self._pack_pks_expr(schema_dict, ids)

        if not output_fields:
            output_fields = ["*"]

        kwargs = self._with_cluster_id(kwargs)
        return await conn.query(
            collection_name,
            expr=filter,
            output_fields=output_fields,
            partition_names=partition_names,
            timeout=timeout,
            expr_params=kwargs.pop("filter_params", {}),
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get(
        self,
        collection_name: str,
        ids: Union[list, str, int],
        output_fields: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        partition_names: Optional[List[str]] = None,
        **kwargs,
    ) -> List[dict]:
        if not isinstance(ids, list):
            ids = [ids]

        if len(ids) == 0:
            return []

        conn = await self._get_connection()
        try:
            schema_dict, _ = await conn._get_schema(
                collection_name,
                timeout=timeout,
                context=self._generate_call_context(**kwargs),
                **kwargs,
            )
        except Exception as ex:
            raise ex from ex

        if not output_fields:
            output_fields = ["*"]

        expr = self._pack_pks_expr(schema_dict, ids)
        kwargs = self._with_cluster_id(kwargs)
        return await conn.query(
            collection_name,
            expr=expr,
            output_fields=output_fields,
            partition_names=partition_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def delete(
        self,
        collection_name: str,
        ids: Optional[Union[list, str, int]] = None,
        timeout: Optional[float] = None,
        filter: Optional[str] = None,
        partition_name: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, int]:
        pks = kwargs.get("pks", [])
        if isinstance(pks, (int, str)):
            pks = [pks]

        for pk in pks:
            if not isinstance(pk, (int, str)):
                msg = f"wrong type of argument pks, expect list, int or str, got '{type(pk).__name__}'"
                raise TypeError(msg)

        if ids is not None:
            if isinstance(ids, (int, str)):
                pks.append(ids)
            elif isinstance(ids, list):
                for id in ids:
                    if not isinstance(id, (int, str)):
                        msg = f"wrong type of argument ids, expect list, int or str, got '{type(id).__name__}'"
                        raise TypeError(msg)
                pks.extend(ids)
            else:
                msg = f"wrong type of argument ids, expect list, int or str, got '{type(ids).__name__}'"
                raise TypeError(msg)

        # validate ambiguous delete filter param before describe collection rpc
        if filter and len(pks) > 0:
            raise ParamError(message=ExceptionsMessage.AmbiguousDeleteFilterParam)

        expr = ""
        conn = await self._get_connection()
        if len(pks) > 0:
            try:
                schema_dict, _ = await conn._get_schema(
                    collection_name,
                    timeout=timeout,
                    context=self._generate_call_context(**kwargs),
                    **kwargs,
                )
            except Exception as ex:
                raise ex from ex
            expr = self._pack_pks_expr(schema_dict, pks)
        else:
            if not isinstance(filter, str):
                raise DataTypeNotMatchException(message=ExceptionsMessage.ExprType % type(filter))
            expr = filter

        ret_pks = []
        res = await conn.delete(
            collection_name=collection_name,
            expression=expr,
            partition_name=partition_name,
            expr_params=kwargs.pop("filter_params", {}),
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        if res.primary_keys:
            ret_pks.extend(res.primary_keys)

        # compatible with deletions that returns primary keys
        if ret_pks:
            return ret_pks

        return OmitZeroDict({"delete_count": res.delete_count, "cost": res.cost})

    async def describe_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ) -> dict:
        conn = await self._get_connection()
        result = await conn.describe_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        # Convert internal struct_array_fields to user-friendly format
        if isinstance(result, dict) and "struct_array_fields" in result:
            converted_fields = convert_struct_fields_to_user_format(result["struct_array_fields"])
            result["fields"].extend(converted_fields)
            # Remove internal struct_array_fields from user-facing response
            result.pop("struct_array_fields")
        return result

    async def has_collection(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ) -> bool:
        conn = await self._get_connection()
        return await conn.has_collection(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_collections(self, timeout: Optional[float] = None, **kwargs) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_collections(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def get_collection_stats(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ) -> Dict:
        conn = await self._get_connection()
        stats = await conn.get_collection_stats(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        result = {stat.key: stat.value for stat in stats}
        if "row_count" in result:
            result["row_count"] = int(result["row_count"])
        return result

    async def get_partition_stats(
        self, collection_name: str, partition_name: str, timeout: Optional[float] = None, **kwargs
    ) -> Dict:
        conn = await self._get_connection()
        stats = await conn.get_partition_stats(
            collection_name,
            partition_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        result = {stat.key: stat.value for stat in stats}
        if "row_count" in result:
            result["row_count"] = int(result["row_count"])
        return result

    async def get_load_state(
        self,
        collection_name: str,
        partition_names: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        state = await conn.get_load_state(
            collection_name,
            partition_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

        ret = {"state": state}
        if state == LoadState.Loading:
            progress = await conn.get_loading_progress(
                collection_name,
                partition_names,
                timeout=timeout,
                context=self._generate_call_context(**kwargs),
                **kwargs,
            )
            ret["progress"] = progress

        return ret

    async def refresh_load(
        self,
        collection_name: str,
        partition_names: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        return await conn.refresh_load(
            collection_name,
            partition_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get_server_version(
        self, timeout: Optional[float] = None, detail: bool = False, **kwargs
    ) -> Union[str, Dict]:
        """Get the running server's version

        Args:
            timeout: A duration of time in seconds to allow for the RPC.
            detail: If True, return detailed server info. Defaults to False.

        Returns:
            str: Server version when detail=False.
            dict: Detailed server info when detail=True.
        """
        conn = await self._get_connection()
        return await conn.get_server_version(
            timeout=timeout, detail=detail, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def describe_replica(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        return await conn.describe_replica(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def alter_collection_properties(
        self, collection_name: str, properties: dict, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.alter_collection_properties(
            collection_name,
            properties=properties,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_collection_properties(
        self,
        collection_name: str,
        property_keys: List[str],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.drop_collection_properties(
            collection_name,
            property_keys=property_keys,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def alter_collection_field(
        self,
        collection_name: str,
        field_name: str,
        field_params: dict,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.alter_collection_field(
            collection_name,
            field_name=field_name,
            field_params=field_params,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def add_collection_field(
        self,
        collection_name: str,
        field_name: str,
        data_type: DataType,
        desc: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ):
        if type_info.is_vector_type(data_type) and not kwargs.get("nullable", False):
            raise ParamError(
                message="Adding vector field to existing collection requires nullable=True"
            )
        field_schema = self.create_field_schema(field_name, data_type, desc, **kwargs)
        conn = await self._get_connection()
        await conn.add_collection_field(
            collection_name,
            field_schema,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def add_collection_struct_field(
        self,
        collection_name: str,
        field_name: str,
        struct_schema: StructFieldSchema,
        max_capacity: int,
        desc: Optional[str] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """Add a new nullable struct field to the collection."""
        if not isinstance(struct_schema, StructFieldSchema):
            raise ParamError(message="struct_schema must be StructFieldSchema")
        if not kwargs.get("nullable", True):
            raise ParamError(
                message="Adding struct field to existing collection requires nullable=True"
            )

        struct_field_schema = copy.deepcopy(struct_schema)
        struct_field_schema.name = field_name
        struct_field_schema.max_capacity = max_capacity
        if desc is not None:
            struct_field_schema._description = desc
        struct_field_schema._nullable = True

        if "mmap_enabled" in kwargs:
            struct_field_schema._type_params["mmap_enabled"] = kwargs["mmap_enabled"]
        if "warmup" in kwargs:
            struct_field_schema._type_params["warmup"] = kwargs["warmup"]

        conn = await self._get_connection()
        await conn.add_collection_struct_field(
            collection_name,
            struct_field_schema,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    @deprecated(
        "AsyncMilvusClient.add_collection_function",
        replacement="AsyncMilvusClient.add_function_field",
        reason="is unsupported by Milvus 3.0 and later",
    )
    async def add_collection_function(
        self, collection_name: str, function: Function, timeout: Optional[float] = None, **kwargs
    ):
        """Deprecated: Use add_function_field instead.

        Milvus 3.0 and later do not support adding a function separately. The replacement
        adds the function together with its output field and index.

        Args:
            collection_name(``string``): The name of collection.
            function(``Function``):  The function schema.
            timeout (``float``, optional): A duration of time in seconds to allow for the RPC.
                If timeout is set to None, the client keeps waiting until the server
                responds or an error occurs.
            **kwargs (``dict``): Optional field params

        Raises:
            MilvusException: If anything goes wrong
        """
        conn = await self._get_connection()
        await conn.add_collection_function(
            collection_name,
            function,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def alter_collection_function(
        self,
        collection_name: str,
        function_name: str,
        function: Function,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """Alter a function in the collection.

        Args:
            collection_name(``string``): The name of collection.
            function_name(``string``): The function name that needs to be modified
            function(``Function``):  The function schema.
            timeout (``float``, optional): A duration of time in seconds to allow for the RPC.
                If timeout is set to None, the client keeps waiting until the server
                responds or an error occurs.
            **kwargs (``dict``): Optional field params

        Raises:
            MilvusException: If anything goes wrong
        """
        conn = await self._get_connection()
        await conn.alter_collection_function(
            collection_name,
            function_name,
            function,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    @deprecated(
        "AsyncMilvusClient.drop_collection_function",
        replacement="AsyncMilvusClient.drop_function_field",
        reason="is unsupported by Milvus 3.0 and later",
    )
    async def drop_collection_function(
        self, collection_name: str, function_name: str, timeout: Optional[float] = None, **kwargs
    ):
        """Deprecated: Use drop_function_field instead.

        Milvus 3.0 and later do not support dropping a function separately. The replacement
        also removes the function's output field and its index.

        Args:
            collection_name(``string``): The name of collection.
            function_name(``string``): The function name that needs to be dropped
            timeout (``float``, optional): A duration of time in seconds to allow for the RPC.
                If timeout is set to None, the client keeps waiting until the server
                responds or an error occurs.
            **kwargs (``dict``): Optional field params

        Raises:
            MilvusException: If anything goes wrong
        """
        conn = await self._get_connection()
        await conn.drop_collection_function(
            collection_name,
            function_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_function_field(
        self, collection_name: str, function_name: str, timeout: Optional[float] = None, **kwargs
    ):
        """Drop a function and its output field from the collection."""
        await self._alter_collection_schema(
            collection_name=collection_name,
            drop_function_name=function_name,
            drop_function_output_fields=True,
            timeout=timeout,
            **kwargs,
        )

    async def drop_collection_field(
        self,
        collection_name: str,
        field_name: str = "",
        field_id: int = 0,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """Drop a field from the collection."""
        await self._alter_collection_schema(
            collection_name=collection_name,
            drop_field_name=field_name,
            drop_field_id=field_id,
            timeout=timeout,
            **kwargs,
        )

    async def _alter_collection_schema(
        self,
        collection_name: str,
        field_schema: Optional[FieldSchema] = None,
        func: Optional[Function] = None,
        timeout: Optional[float] = None,
        drop_field_name: Optional[str] = None,
        drop_field_id: Optional[int] = None,
        drop_function_name: Optional[str] = None,
        drop_function_output_fields: bool = False,
        index_name: str = "",
        index_extra_params: Optional[Dict] = None,
        **kwargs,
    ):
        """Alter collection schema supporting both Add and Drop operations.

        For Add operation: provide field_schema and func
        For Drop operation: provide either drop_field_name, drop_field_id, or drop_function_name

        Args:
            collection_name(``str``): The name of the collection.
            field_schema(``FieldSchema``, optional): Field schema to add.
            func(``Function``, optional): Function to add.
            timeout(``float``, optional): Timeout for the operation.
            drop_field_name(``str``, optional): Field name to drop.
            drop_field_id(``int``, optional): Field ID to drop.
            drop_function_name(``str``, optional): Function name to drop.
            **kwargs(``dict``): Additional keyword arguments.

        Raises:
            ParamError: If operation parameters are invalid.
            MilvusException: If the operation fails.
        """
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()

        is_drop = any(
            identifier is not None
            for identifier in (drop_field_name, drop_field_id, drop_function_name)
        )
        is_add = field_schema is not None or func is not None

        if is_drop and is_add:
            raise ParamError(
                message="Cannot perform both Add and Drop operations in a single request"
            )
        if not is_drop and not is_add:
            raise ParamError(
                message="Must specify either Add operation (field_schema/func) or Drop operation (drop_field_name/drop_field_id/drop_function_name)"
            )

        if is_add:
            if field_schema is None:
                raise ParamError(message="field_schema is required for Add operation")
            if func is None:
                raise ParamError(message="func is required for Add operation")

            await conn.alter_collection_schema(
                collection_name=collection_name,
                field_schema=field_schema,
                func=func,
                timeout=timeout,
                index_name=index_name,
                index_extra_params=index_extra_params,
                context=self._generate_call_context(**kwargs),
                **kwargs,
            )
        else:
            valid_drop_identifiers = [
                drop_field_name is not None and drop_field_name != "",
                drop_field_id is not None and drop_field_id > 0,
                drop_function_name is not None and drop_function_name != "",
            ]
            if sum(valid_drop_identifiers) != 1:
                raise ParamError(
                    message="Must specify exactly one valid Drop identifier (drop_field_name/drop_field_id/drop_function_name)"
                )

            await conn.alter_collection_schema(
                collection_name=collection_name,
                drop_field_name=drop_field_name,
                drop_field_id=drop_field_id,
                drop_function_name=drop_function_name,
                drop_function_output_fields=drop_function_output_fields,
                timeout=timeout,
                context=self._generate_call_context(**kwargs),
                **kwargs,
            )

    async def add_function_field(
        self,
        collection_name: str,
        field_schema: FieldSchema,
        func: Function,
        index_params: IndexParams,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """Add a function-backed field (e.g. BM25 sparse vector or MinHash binary vector)."""
        validate_param("collection_name", collection_name, str)
        validate_param("field_schema", field_schema, FieldSchema)
        validate_param("func", func, Function)

        supported_function_outputs = {
            FunctionType.BM25: DataType.SPARSE_FLOAT_VECTOR,
            FunctionType.MINHASH: DataType.BINARY_VECTOR,
        }
        expected_dtype = supported_function_outputs.get(func.type)
        if expected_dtype is None:
            raise ParamError(
                message=(
                    "add_function_field only supports FunctionType.BM25 with SPARSE_FLOAT_VECTOR "
                    f"or FunctionType.MINHASH with BINARY_VECTOR for now, got {func.type}"
                )
            )
        if field_schema.dtype != expected_dtype:
            raise ParamError(
                message=(
                    f"add_function_field requires {expected_dtype.name} output field for {func.type}, "
                    f"got {field_schema.dtype}"
                )
            )

        bound_index_name, bound_index_extra_params = extract_bound_index_param(
            field_schema.name, index_params
        )

        await self._alter_collection_schema(
            collection_name=collection_name,
            field_schema=field_schema,
            func=func,
            timeout=timeout,
            index_name=bound_index_name,
            index_extra_params=bound_index_extra_params,
            **kwargs,
        )

    async def close(self):
        """Close the client and release the connection."""
        self._closed = True
        if self._manager and self._handler:
            await self._manager.release(self._handler, client=self)
            self._handler = None

    async def list_indexes(self, collection_name: str, field_name: Optional[str] = "", **kwargs):
        conn = await self._get_connection()
        indexes = await conn.list_indexes(
            collection_name, context=self._generate_call_context(**kwargs), **kwargs
        )
        index_name_list = []
        for index in indexes:
            if not index:
                continue
            if not field_name or index.field_name == field_name:
                index_name_list.append(index.index_name)
        return index_name_list

    async def describe_index(
        self, collection_name: str, index_name: str, timeout: Optional[float] = None, **kwargs
    ) -> Dict:
        conn = await self._get_connection()
        return await conn.describe_index(
            collection_name,
            index_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def alter_index_properties(
        self,
        collection_name: str,
        index_name: str,
        properties: dict,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.alter_index_properties(
            collection_name,
            index_name,
            properties=properties,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_index_properties(
        self,
        collection_name: str,
        index_name: str,
        property_keys: List[str],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.drop_index_properties(
            collection_name,
            index_name,
            property_keys=property_keys,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def create_alias(
        self, collection_name: str, alias: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.create_alias(
            collection_name,
            alias,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_alias(self, alias: str, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        await conn.drop_alias(
            alias, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def alter_alias(
        self, collection_name: str, alias: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.alter_alias(
            collection_name,
            alias,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def describe_alias(self, alias: str, timeout: Optional[float] = None, **kwargs) -> Dict:
        conn = await self._get_connection()
        return await conn.describe_alias(
            alias, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def list_aliases(
        self, collection_name: str = "", timeout: Optional[float] = None, **kwargs
    ) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_aliases(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    @deprecated(
        "AsyncMilvusClient.using_database",
        replacement="AsyncMilvusClient.use_database",
        reason="is deprecated",
    )
    async def using_database(self, db_name: str, **kwargs):
        """Deprecated: Use use_database instead."""
        await self.use_database(db_name, **kwargs)

    async def use_database(self, db_name: str, **kwargs):
        """Switch to a different database. Future operations will use this database.

        Args:
            db_name (str): The name of the database to switch to.
            **kwargs: Additional keyword arguments (e.g., timeout).

        Raises:
            MilvusException: If the database does not exist (error code 800).
        """
        await self.describe_database(db_name, **kwargs)
        self._config.db_name = db_name

    async def create_database(
        self,
        db_name: str,
        properties: Optional[dict] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.create_database(
            db_name=db_name,
            properties=properties,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_database(self, db_name: str, **kwargs):
        conn = await self._get_connection()
        await conn.drop_database(db_name, context=self._generate_call_context(**kwargs), **kwargs)

    async def list_databases(self, timeout: Optional[float] = None, **kwargs) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_database(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def describe_database(self, db_name: str, **kwargs) -> dict:
        conn = await self._get_connection()
        return await conn.describe_database(
            db_name, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def alter_database_properties(self, db_name: str, properties: dict, **kwargs):
        conn = await self._get_connection()
        await conn.alter_database(
            db_name, properties, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def drop_database_properties(self, db_name: str, property_keys: List[str], **kwargs):
        conn = await self._get_connection()
        await conn.drop_database_properties(
            db_name, property_keys, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def create_user(
        self,
        user_name: str,
        password: str,
        timeout: Optional[float] = None,
        description: Optional[str] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.create_user(
            user_name,
            password,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            description=description,
            **kwargs,
        )

    async def drop_user(self, user_name: str, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        await conn.drop_user(
            user_name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def update_password(
        self,
        user_name: str,
        old_password: str,
        new_password: str,
        timeout: Optional[float] = None,
        description: Optional[str] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.update_password(
            user_name,
            old_password,
            new_password,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            description=description,
            **kwargs,
        )

    async def update_user(
        self,
        user_name: str,
        description: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.update_user(
            user_name,
            description=description,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_users(self, timeout: Optional[float] = None, **kwargs) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_users(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def describe_user(
        self, user_name: str, timeout: Optional[float] = None, **kwargs
    ) -> dict:
        conn = await self._get_connection()
        res = await conn.describe_user(
            user_name,
            True,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        if hasattr(res, "results") and res.results:
            user_info = UserInfo(res.results)
            if user_info.groups:
                item = user_info.groups[0]
                return {
                    "user_name": user_name,
                    "roles": item.roles,
                    "description": item.description,
                }
        return {}

    async def create_privilege_group(
        self,
        group_name: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.create_privilege_group(
            group_name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def drop_privilege_group(
        self,
        group_name: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.drop_privilege_group(
            group_name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def list_privilege_groups(
        self,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> List[Dict[str, Union[str, List[str]]]]:
        conn = await self._get_connection()
        res = await conn.list_privilege_groups(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )
        ret = []
        for g in res:
            privileges = []
            for p in g.privileges:
                privileges.append(p.name)
            ret.append({"privilege_group": g.group_name, "privileges": privileges})
        return ret

    async def add_privileges_to_group(
        self,
        group_name: str,
        privileges: List[str],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.add_privileges_to_group(
            group_name,
            privileges,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def remove_privileges_from_group(
        self,
        group_name: str,
        privileges: List[str],
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.remove_privileges_from_group(
            group_name,
            privileges,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def create_role(
        self, role_name: str, timeout: Optional[float] = None, description: str = "", **kwargs
    ):
        conn = await self._get_connection()
        await conn.create_role(
            role_name,
            timeout=timeout,
            description=description,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def alter_role(
        self, role_name: str, description: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.alter_role(
            role_name,
            description,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_role(
        self, role_name: str, force_drop: bool = False, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.drop_role(
            role_name,
            force_drop=force_drop,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def grant_role(
        self, user_name: str, role_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.grant_role(
            user_name,
            role_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def revoke_role(
        self, user_name: str, role_name: str, timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.revoke_role(
            user_name,
            role_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def grant_privilege(
        self,
        role_name: str,
        object_type: str,
        privilege: str,
        object_name: str,
        db_name: Optional[str] = "",
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.grant_privilege(
            role_name,
            object_type,
            object_name,
            privilege,
            db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def revoke_privilege(
        self,
        role_name: str,
        object_type: str,
        privilege: str,
        object_name: str,
        db_name: Optional[str] = "",
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.revoke_privilege(
            role_name,
            object_type,
            object_name,
            privilege,
            db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def grant_privilege_v2(
        self,
        role_name: str,
        privilege: str,
        collection_name: str,
        db_name: Optional[str] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.grant_privilege_v2(
            role_name,
            privilege,
            collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def revoke_privilege_v2(
        self,
        role_name: str,
        privilege: str,
        collection_name: str,
        db_name: Optional[str] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.revoke_privilege_v2(
            role_name,
            privilege,
            collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def describe_role(
        self, role_name: str, timeout: Optional[float] = None, **kwargs
    ) -> Dict:
        conn = await self._get_connection()
        context = self._generate_call_context(**kwargs)
        db_name = kwargs.pop("db_name", "")
        role_info = RoleInfo(
            await conn.describe_role(role_name, False, timeout=timeout, context=context, **kwargs)
        )
        res = await conn.select_grant_for_one_role(
            role_name, db_name, timeout=timeout, context=context, **kwargs
        )
        ret = {}
        ret["role"] = role_name
        ret["description"] = role_info.groups[0].description if role_info.groups else ""
        ret["privileges"] = [dict(i) for i in res.groups]
        return ret

    async def list_roles(self, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        res = await conn.list_roles(
            False, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

        role_info = RoleInfo(res)
        return [g.role_name for g in role_info.groups]

    async def create_resource_group(self, name: str, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        await conn.create_resource_group(
            name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def drop_resource_group(self, name: str, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        await conn.drop_resource_group(
            name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def update_resource_groups(
        self, configs: Dict[str, ResourceGroupConfig], timeout: Optional[float] = None, **kwargs
    ):
        conn = await self._get_connection()
        await conn.update_resource_groups(
            configs, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def describe_resource_group(self, name: str, timeout: Optional[float] = None, **kwargs):
        conn = await self._get_connection()
        return await conn.describe_resource_group(
            name, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def list_resource_groups(self, timeout: Optional[float] = None, **kwargs) -> List[str]:
        conn = await self._get_connection()
        return await conn.list_resource_groups(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def transfer_replica(
        self,
        source: str,
        target: str,
        collection_name: str,
        num_replica: int,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        await conn.transfer_replica(
            source,
            target,
            collection_name,
            num_replica,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def flush(self, collection_name: str, timeout: Optional[float] = None, **kwargs):
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()
        await conn.flush(
            [collection_name],
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def flush_all(self, timeout: Optional[float] = None, **kwargs) -> None:
        """Flush all collections.

        Args:
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.
        """
        conn = await self._get_connection()
        await conn.flush_all(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def get_flush_all_state(self, timeout: Optional[float] = None, **kwargs) -> bool:
        """Get the flush all state.

        Args:
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            bool: True if flush all operation is completed, False otherwise.
        """
        conn = await self._get_connection()
        return await conn.get_flush_all_state(
            timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def list_persistent_segments(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        states: Optional[Sequence[SegmentState]] = None,
        **kwargs,
    ) -> List[SegmentInfo]:
        """List persistent segments for a collection.

        Args:
            collection_name (str): The name of the collection.
            states (Optional[Sequence[SegmentState]]): Segment states to include; when omitted,
                the server preserves the legacy persistent-state filter.
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            List[SegmentInfo]: A list of persistent segment information.
        """
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()
        infos = await conn.get_persistent_segment_infos(
            collection_name,
            states=states,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        return [
            SegmentInfo(
                segment_id=info.segmentID,
                collection_id=info.collectionID,
                collection_name=collection_name,
                num_rows=info.num_rows,
                is_sorted=info.is_sorted,
                state=info.state,
                level=info.level,
                storage_version=info.storage_version,
                partition_id=info.partitionID,
                insert_channel=info.insert_channel,
                compaction_from=list(info.compaction_from),
            )
            for info in infos
        ]

    async def list_segments(
        self,
        collection_name: str,
        states: Optional[Sequence[SegmentState]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> List[SegmentInfo]:
        """List collection segments still retained in the requested lifecycle states."""
        if states is None:
            states = _DEFAULT_RETAINED_SEGMENT_STATES
        return await self.list_persistent_segments(
            collection_name,
            states=states,
            timeout=timeout,
            **kwargs,
        )

    async def compact(
        self,
        collection_name: str,
        is_clustering: Optional[bool] = False,
        is_l0: Optional[bool] = False,
        target_size: Optional[int] = None,
        target_size_unit: str = "mb",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> int:
        """Compact merge the small segments in a collection.

        Args:
            collection_name (str): The name of the collection to compact.
            is_clustering (``bool``, optional): Option to trigger clustering compaction.
            is_l0 (``bool``, optional): Option to trigger L0 compaction.
            target_size (``int``, optional): Target segment size after compaction. Must be a
                positive integer. The unit is specified by ``target_size_unit`` (default MB).
                If not provided, the server uses its default target size.
            target_size_unit (``str``, optional): Unit for ``target_size``. Supported values:
                ``"b"``, ``"kb"``, ``"mb"`` (default), ``"gb"``, ``"tb"``, ``"pb"``.
                The value is converted to MB before being sent to the server.
            timeout (``float``, optional): An optional duration of time in seconds to allow
                for the RPC. When timeout is set to None, client waits until server response
                or error occur.

        Raises:
            ParamError: If ``target_size`` is not an int or ``target_size_unit`` is invalid.
            MilvusException: If anything goes wrong.

        Returns:
            int: An integer represents the server's compaction job. You can use this job ID
            for subsequent state inquiries.
        """
        if target_size is not None:
            if not isinstance(target_size, int) or isinstance(target_size, bool):
                raise ParamError(
                    message=f"target_size must be an int, got {type(target_size).__name__}"
                )
            if target_size <= 0:
                raise ParamError(
                    message=f"target_size must be a positive integer, got {target_size}"
                )
            target_size = parse_target_size(f"{target_size}{target_size_unit}")

        conn = await self._get_connection()
        return await conn.compact(
            collection_name,
            is_clustering=is_clustering,
            is_l0=is_l0,
            target_size=target_size,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get_compaction_state(
        self, job_id: int, timeout: Optional[float] = None, **kwargs
    ) -> str:
        conn = await self._get_connection()
        result = await conn.get_compaction_state(
            job_id, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )
        return result.state_name

    async def get_compaction_plans(
        self,
        job_id: int,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """Get compaction plans for a specific job.

        Args:
            job_id (int): The ID of the compaction job.
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            CompactionPlans: The compaction plans for the specified job.
        """
        conn = await self._get_connection()
        return await conn.get_compaction_plans(
            job_id, timeout=timeout, context=self._generate_call_context(**kwargs), **kwargs
        )

    async def list_compaction_tasks(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> CompactionPlans:
        """List all compaction tasks still retained for a collection."""
        validate_param("collection_name", collection_name, str)
        conn = await self._get_connection()
        return await conn.get_compaction_tasks(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def run_analyzer(
        self,
        texts: Union[str, List[str]],
        analyzer_params: Optional[Union[str, Dict]] = None,
        with_hash: bool = False,
        with_detail: bool = False,
        collection_name: Optional[str] = None,
        field_name: Optional[str] = None,
        analyzer_names: Optional[Union[str, List[str]]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        return await conn.run_analyzer(
            texts,
            analyzer_params=analyzer_params,
            with_hash=with_hash,
            with_detail=with_detail,
            collection_name=collection_name,
            field_name=field_name,
            analyzer_names=analyzer_names,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def update_replicate_configuration(
        self,
        clusters: Optional[List[Dict]] = None,
        cross_cluster_topology: Optional[List[Dict]] = None,
        force_promote: bool = False,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """
        Update replication configuration across Milvus clusters.

        Args:
            clusters (List[Dict], optional): List of cluster configurations.
            Each dict should contain:
                - cluster_id (str): Unique identifier for the cluster
                - connection_param (Dict): Connection parameters with 'uri' and 'token'
                - pchannels (List[str], optional): Physical channels for the cluster

            cross_cluster_topology (List[Dict], optional): List of replication relationships.
            Each dict should contain:
                - source_cluster_id (str): ID of the source cluster
                - target_cluster_id (str): ID of the target cluster

            force_promote (bool, optional): If true, force promote the current secondary cluster
                to standalone primary. Used for disaster recovery when the primary is unavailable.

            timeout (float, optional): An optional duration of time in seconds to allow for the RPC
            **kwargs: Additional arguments

        Returns:
            Status: The status of the operation

        Raises:
            ParamError: If neither clusters nor cross_cluster_topology is provided
            MilvusException: If the operation fails
        """
        conn = await self._get_connection()
        return await conn.update_replicate_configuration(
            clusters=clusters,
            cross_cluster_topology=cross_cluster_topology,
            force_promote=force_promote,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get_replicate_configuration(
        self,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """
        Get replication configuration from Milvus.

        Args:
            timeout (float, optional): An optional duration of time in seconds to allow for the RPC
            **kwargs: Additional arguments

        Returns:
            ReplicateConfiguration: The current replication configuration

        Raises:
            MilvusException: If the operation fails
        """
        conn = await self._get_connection()
        return await conn.get_replicate_configuration(
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get_replicate_info(
        self,
        source_cluster_id: str,
        target_pchannel: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """
        Get replication checkpoint state for a source cluster + source pchannel.

        Args:
            source_cluster_id (str): ID of the source cluster.
            target_pchannel (str): The SOURCE cluster's pchannel name. The proto
                field naming is historical and misleading; the value expected here
                is the pchannel belonging to source_cluster_id.
            timeout (float, optional): RPC timeout in seconds.

        Returns:
            dict: {
                "checkpoint": dict or None — current replication position,
                "salvage_checkpoint": dict or None — last-known position from a
                    prior force_promote (None when no force_promote occurred),
            }
            Each non-None checkpoint dict has keys: cluster_id (str), pchannel (str),
            message_id ({"id": str, "wal_name": str} or None), time_tick (int).

        Raises:
            ParamError: If source_cluster_id or target_pchannel is empty.
            MilvusException: If the RPC fails.

        Note:
            This is the async coroutine version; callers must `await` it.

        Examples:
            await client.get_replicate_info(
                source_cluster_id="primary",
                target_pchannel="by-dev-rootcoord-dml_0",
            )
        """
        conn = await self._get_connection()
        return await conn.get_replicate_info(
            source_cluster_id=source_cluster_id,
            target_pchannel=target_pchannel,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def dump_messages(
        self,
        pchannel: str,
        start_message_id: Dict,
        start_timetick: int = 0,
        end_timetick: int = 0,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """
        Dump messages from a WAL range for data salvage (server-streaming RPC).

        Async generator version — iterate with ``async for``. See
        MilvusClient.dump_messages for full parameter and return-value docs.

        Note:
            Because this is an async generator, parameter validation errors
            (ParamError) surface at the first iteration step, not at call time.

        Examples:
            async for msg in client.dump_messages(
                pchannel="by-dev-rootcoord-dml_0",
                start_message_id=ckpt["message_id"],
                start_timetick=ckpt["time_tick"],
                end_timetick=end_tt,
            ):
                print(msg["message_id"], len(msg["payload"]))
        """
        conn = await self._get_connection()
        async for msg in conn.dump_messages(
            pchannel=pchannel,
            start_message_id=start_message_id,
            start_timetick=start_timetick,
            end_timetick=end_timetick,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        ):
            yield msg

    async def _is_collection_loaded(
        self, collection_name: str, timeout: Optional[float] = None
    ) -> bool:
        state_dict = await self.get_load_state(collection_name, timeout=timeout)
        return state_dict.get("state") == LoadState.Loaded

    async def _list_vector_indexes(
        self, collection_name: str, timeout: Optional[float] = None, **kwargs
    ) -> List[str]:
        conn = await self._get_connection()
        schema_dict, _ = await conn._get_schema(
            collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )
        vector_fields = {
            field["name"]
            for field in schema_dict.get("fields", [])
            if type_info.is_vector_type(field.get("type"))
        }

        if not vector_fields:
            return []

        all_indexes = await self.list_indexes(collection_name, **kwargs)

        vector_indexes = []
        if all_indexes:
            describe_tasks = [
                self.describe_index(collection_name, index_name, timeout=timeout, **kwargs)
                for index_name in all_indexes
            ]
            index_infos = await asyncio.gather(*describe_tasks)

            vector_indexes = [
                all_indexes[i]
                for i, index_info in enumerate(index_infos)
                if index_info and index_info.get("field_name") in vector_fields
            ]
        return vector_indexes

    async def _wait_for_indexes(
        self,
        task: AsyncOptimizeTask,
        collection_name: str,
        index_names: List[str],
        timeout: Optional[float] = None,
        **kwargs,
    ) -> None:
        if not index_names:
            return

        task.check_cancelled()

        conn = await self._get_connection()
        wait_tasks = [
            conn.wait_for_creating_index(
                collection_name, index_name, context=self._generate_call_context(**kwargs), **kwargs
            )
            for index_name in index_names
        ]

        try:
            await asyncio.wait_for(asyncio.gather(*wait_tasks), timeout=timeout)
        except asyncio.TimeoutError as e:
            raise MilvusException(
                message=f"Timeout waiting for indexes to complete on collection {collection_name}"
            ) from e

    async def _wait_for_compaction_with_cancel(
        self, task: AsyncOptimizeTask, compaction_id: int, timeout: Optional[float] = None, **kwargs
    ) -> None:
        start = time.time()
        conn = await self._get_connection()
        while True:
            task.check_cancelled()

            if timeout is not None:
                elapsed = time.time() - start
                if elapsed >= timeout:
                    raise MilvusException(
                        message=f"Timeout waiting for compaction {compaction_id} to complete"
                    )
                remaining_timeout = timeout - elapsed
            else:
                remaining_timeout = None

            state = await conn.get_compaction_state(
                compaction_id,
                timeout=remaining_timeout,
                context=self._generate_call_context(**kwargs),
                **kwargs,
            )
            if state.state == 2:
                break
            if state.state == 3:
                raise MilvusException(message=f"Compaction {compaction_id} failed")

            await asyncio.sleep(0.5)

    async def optimize(
        self,
        collection_name: str,
        target_size: Optional[str] = None,
        wait: bool = True,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> Union[OptimizeResult, AsyncOptimizeTask]:
        """Optimize collection to adjust segment sizes for better query performance.

        WARNING: This is a Preview version feature for non-production use only (Benchmark, POC).

        This method performs the following operations:
        1. Waits for all indexes to complete building
        2. Triggers force merge compaction with optional target size
        3. Waits for compaction to complete
        4. Waits for index rebuild to complete
        5. Refreshes collection load if collection is loaded

        Args:
            collection_name (str): The name of the collection to optimize.
            target_size (Optional[str]): Target segment size. Format: '1000MB', '1GB', '1.2gb'.
                If not provided, uses system default.
            wait (bool): Whether to wait for optimization to complete. Defaults to True.
                If False, returns an OptimizeTask for async tracking.
            timeout (Optional[float]): Maximum time in seconds to wait for optimization.
                Only applies when wait=True.
            **kwargs: Additional arguments.

        Returns:
            Union[OptimizeResult, AsyncOptimizeTask]: If wait=True, returns OptimizeResult with:
                - status: "success"
                - collection_name: str
                - compaction_id: int
                - target_size: str or None
                - progress: list of progress stages completed
            If wait=False, returns AsyncOptimizeTask for progress tracking.

        Raises:
            ParamError: If collection_name is invalid or target_size format is incorrect.
            MilvusException: If index build fails, compaction fails, or timeout occurs.

        Examples:
            Synchronous usage:
            >>> await client.optimize("my_collection", target_size="512MB")

            Asynchronous usage:
            >>> task = await client.optimize("my_collection", target_size="512MB", wait=False)
            >>> while not task.done():
            ...     print(f"Progress: {task.progress()}")
            ...     await asyncio.sleep(1)
            >>> result = task.result()

            Cancelling a task:
            >>> task = await client.optimize("my_collection", target_size="512MB", wait=False)
            >>> # ... do some work ...
            >>> if task.cancel():
            ...     print("Task cancelled successfully")
        """
        validate_param("collection_name", collection_name, str)

        task = AsyncOptimizeTask(
            collection_name=collection_name,
            target_size=target_size,
            task_timeout=timeout,
            execute_fn=self._execute_optimize,
            **kwargs,
        )
        task.start()

        if wait:
            return await task.result(timeout=timeout)

        return task

    async def _execute_optimize(
        self,
        task: AsyncOptimizeTask,
        collection_name: str,
        size_mb: Optional[int],
        timeout: Optional[float],
        **kwargs,
    ) -> OptimizeResult:
        start = time.time()

        def remaining_timeout() -> Optional[float]:
            if timeout is None:
                return None
            elapsed = time.time() - start
            return max(0, timeout - elapsed)

        task.check_cancelled()
        vector_indexes = await self._list_vector_indexes(
            collection_name, timeout=remaining_timeout(), **kwargs
        )

        task.check_cancelled()
        task.set_progress(ProgressStage.WAITING_FOR_INDEXES)
        await self._wait_for_indexes(
            task, collection_name, vector_indexes, timeout=remaining_timeout(), **kwargs
        )

        task.check_cancelled()
        task.set_progress(ProgressStage.COMPACTING)
        conn = await self._get_connection()
        compaction_id = await conn.compact(
            collection_name=collection_name,
            target_size=size_mb,
            timeout=remaining_timeout(),
            **kwargs,
        )

        task.check_cancelled()
        task.set_progress(ProgressStage.WAITING_FOR_COMPACTION)
        await self._wait_for_compaction_with_cancel(
            task, compaction_id, timeout=remaining_timeout(), **kwargs
        )

        task.check_cancelled()
        task.set_progress(ProgressStage.WAITING_FOR_INDEX_REBUILD)
        await self._wait_for_indexes(
            task, collection_name, vector_indexes, timeout=remaining_timeout(), **kwargs
        )

        task.check_cancelled()
        if await self._is_collection_loaded(collection_name, timeout=remaining_timeout()):
            task.set_progress(ProgressStage.REFRESHING_LOAD)
            await self.refresh_load(collection_name, timeout=remaining_timeout(), **kwargs)

        return OptimizeResult(
            status="success",
            collection_name=collection_name,
            compaction_id=compaction_id,
            target_size=task._target_size,
            progress=task.progress_history(),
        )

    async def create_snapshot(
        self,
        snapshot_name: str,
        collection_name: str,
        db_name: str = "",
        description: str = "",
        compaction_protection_seconds: int = 0,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> None:
        """Create a snapshot for a collection (async).

        Args:
            snapshot_name (str): The name of the snapshot. Must be unique.
            collection_name (str): The name of the collection to snapshot.
            description (str): Optional description for the snapshot.
            db_name (str): Optional database name (defaults to active db).
            compaction_protection_seconds (int): Duration in seconds during which the
                snapshot-referenced segments are protected from compaction.
                0 = no protection (default).
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Example:
            >>> client = AsyncMilvusClient(uri="http://localhost:19530")
            >>> await client.flush(collection_name="my_collection")
            >>> await client.create_snapshot(
            ...     snapshot_name="backup_20240101",
            ...     collection_name="my_collection",
            ...     description="Daily backup",
            ...     compaction_protection_seconds=3600,
            ... )
        """
        conn = await self._get_connection()
        await conn.create_snapshot(
            snapshot_name=snapshot_name,
            collection_name=collection_name,
            description=description,
            db_name=db_name,
            compaction_protection_seconds=compaction_protection_seconds,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def drop_snapshot(
        self,
        snapshot_name: str,
        collection_name: str,
        db_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> None:
        """Delete a snapshot permanently (async).

        Args:
            snapshot_name (str): The name of the snapshot to drop.
            collection_name (str): The collection the snapshot belongs to
                (required for collection-level authorization).
            db_name (str): Optional database name (defaults to active db).
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.
        """
        conn = await self._get_connection()
        await conn.drop_snapshot(
            snapshot_name=snapshot_name,
            collection_name=collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_snapshots(
        self,
        collection_name: str = "",
        db_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> List[str]:
        """List existing snapshots (async).

        Args:
            collection_name (str): Optional collection name to filter snapshots.
            db_name (str): Optional database name (defaults to active db).
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            List[str]: A list of snapshot names.
        """
        conn = await self._get_connection()
        return await conn.list_snapshots(
            collection_name=collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def describe_snapshot(
        self,
        snapshot_name: str,
        collection_name: str,
        db_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> SnapshotInfo:
        """Get detailed information about a snapshot (async).

        Args:
            snapshot_name (str): The name of the snapshot to describe.
            collection_name (str): The collection the snapshot belongs to
                (required for collection-level authorization).
            db_name (str): Optional database name (defaults to active db).
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            SnapshotInfo: Snapshot information dataclass.
        """
        conn = await self._get_connection()
        return await conn.describe_snapshot(
            snapshot_name=snapshot_name,
            collection_name=collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def restore_snapshot(
        self,
        snapshot_name: str,
        source_collection_name: str,
        target_collection_name: str,
        source_db_name: str = "",
        target_db_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> int:
        """Restore a snapshot to a new collection (async).

        Args:
            snapshot_name (str): The name of the snapshot to restore.
            target_collection_name (str): The collection the snapshot will be restored into.
                Validated server-side; an existing collection causes the restore job to fail.
            source_collection_name (str): The collection the snapshot belongs to.
                Required to uniquely identify the snapshot, since snapshot names are only
                unique within a collection and multiple collections may share the same name.
            target_db_name (str): Target database name (defaults to active db).
            source_db_name (str): Source database name (defaults to active db).
            timeout (Optional[float]): Optional RPC timeout in seconds.
            **kwargs: Additional arguments.

        Returns:
            int: The restore job ID for tracking progress.
        """
        conn = await self._get_connection()
        return await conn.restore_snapshot(
            snapshot_name=snapshot_name,
            target_collection_name=target_collection_name,
            source_collection_name=source_collection_name,
            target_db_name=target_db_name,
            source_db_name=source_db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def get_restore_snapshot_state(
        self,
        job_id: int,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> RestoreSnapshotJobInfo:
        """Query the status of a restore snapshot job (async).

        Args:
            job_id (int): The restore job ID.
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            RestoreSnapshotJobInfo: Restore job information dataclass.
        """
        conn = await self._get_connection()
        return await conn.get_restore_snapshot_state(
            job_id=job_id,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_restore_snapshot_jobs(
        self,
        collection_name: str = "",
        db_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> List[RestoreSnapshotJobInfo]:
        """List all restore snapshot jobs (async).

        Args:
            collection_name (str): Optional target collection name to filter jobs.
                Pass the name of the collection that was restored into (the target collection).
                If empty, lists all restore jobs.
            db_name (str): Optional database name (defaults to active db).
            timeout (Optional[float]): An optional duration of time in seconds to allow for the RPC.
            **kwargs: Additional arguments.

        Returns:
            List[RestoreSnapshotJobInfo]: A list of RestoreSnapshotJobInfo dataclasses.
        """
        conn = await self._get_connection()
        return await conn.list_restore_snapshot_jobs(
            collection_name=collection_name,
            db_name=db_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def pin_snapshot_data(
        self,
        snapshot_name: str,
        collection_name: str,
        db_name: str = "",
        ttl_seconds: int = 0,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> int:
        """Pin snapshot data to prevent GC during backup/copy (async).

        Returns:
            int: The pin_id. Pass to ``unpin_snapshot_data`` to release.
        """
        conn = await self._get_connection()
        return await conn.pin_snapshot_data(
            snapshot_name=snapshot_name,
            collection_name=collection_name,
            db_name=db_name,
            ttl_seconds=ttl_seconds,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def unpin_snapshot_data(
        self,
        pin_id: int,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> None:
        """Release a pin created by ``pin_snapshot_data`` (async)."""
        conn = await self._get_connection()
        await conn.unpin_snapshot_data(
            pin_id=pin_id,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def add_file_resource(
        self,
        name: str,
        path: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        return await conn.add_file_resource(
            name=name,
            path=path,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def remove_file_resource(
        self,
        name: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        return await conn.remove_file_resource(
            name=name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_file_resources(
        self,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        conn = await self._get_connection()
        return await conn.list_file_resources(
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def refresh_external_collection(
        self,
        collection_name: str,
        external_source: str = "",
        external_spec: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> int:
        """Trigger a data refresh for an external collection (async).

        Args:
            collection_name: The external collection to refresh.
            external_source: Optional new external data source path.
            external_spec: Optional new external spec configuration.
            timeout: RPC timeout in seconds.

        Returns:
            int: A job_id for tracking the refresh progress.
        """
        conn = await self._get_connection()
        return await conn.refresh_external_collection(
            collection_name=collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            external_source=external_source,
            external_spec=external_spec,
            **kwargs,
        )

    async def get_refresh_external_collection_progress(
        self,
        job_id: int,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> RefreshExternalCollectionJobInfo:
        """Get the progress of an external collection refresh job (async).

        Args:
            job_id: The job ID returned by refresh_external_collection().
            timeout: RPC timeout in seconds.

        Returns:
            RefreshExternalCollectionJobInfo with job details.
        """
        conn = await self._get_connection()
        return await conn.get_refresh_external_collection_progress(
            job_id=job_id,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )

    async def list_refresh_external_collection_jobs(
        self,
        collection_name: str = "",
        timeout: Optional[float] = None,
        **kwargs,
    ) -> List:
        """List external collection refresh jobs (async).

        Args:
            collection_name: Optional filter by collection name. Empty lists all.
            timeout: RPC timeout in seconds.

        Returns:
            List of RefreshExternalCollectionJobInfo.
        """
        conn = await self._get_connection()
        return await conn.list_refresh_external_collection_jobs(
            collection_name=collection_name,
            timeout=timeout,
            context=self._generate_call_context(**kwargs),
            **kwargs,
        )


class AsyncMilvusClientSession:
    """Async DQL session bound to a cluster id and backed by a parent client."""

    def __init__(self, parent: AsyncMilvusClient, cluster_id: str) -> None:
        self._parent = parent
        self._cluster_id = cluster_id
        self._closed = False

    def _ensure_open(self) -> None:
        if self._closed:
            raise MilvusException(message="AsyncMilvusClient session is closed")

    def _with_cluster_id(self, kwargs: Dict) -> Dict:
        kwargs[CLUSTER_ID] = self._cluster_id
        return kwargs

    async def close(self) -> None:
        self._closed = True

    async def search(self, *args, **kwargs):
        self._ensure_open()
        return await self._parent.search(*args, **self._with_cluster_id(kwargs))

    async def hybrid_search(self, *args, **kwargs):
        self._ensure_open()
        return await self._parent.hybrid_search(*args, **self._with_cluster_id(kwargs))

    async def query(self, *args, **kwargs):
        self._ensure_open()
        return await self._parent.query(*args, **self._with_cluster_id(kwargs))

    async def get(self, *args, **kwargs):
        self._ensure_open()
        return await self._parent.get(*args, **self._with_cluster_id(kwargs))
